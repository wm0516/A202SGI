package com.example.a202sgi_1;

import android.os.Bundle;
import android.content.Intent;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth; // Firebase Auth instance
    private EditText loginEmail, loginPassword; // Input fields for login

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Initialize UI elements correctly
        TextInputLayout emailLayout = findViewById(R.id.username); // Get the TextInputLayout for email
        TextInputLayout passwordLayout = findViewById(R.id.password); // Get the TextInputLayout for password

        // Get the EditText (or TextInputEditText) inside the TextInputLayout
        loginEmail = emailLayout.getEditText();
        loginPassword = passwordLayout.getEditText();

        // Login button click listener
        Button loginBtn = findViewById(R.id.login_btn);
        loginBtn.setOnClickListener(v -> {
            String email = loginEmail.getText().toString().trim().toLowerCase();
            String password = loginPassword.getText().toString().trim();

            // Input validation
            if (TextUtils.isEmpty(email)) {
                loginEmail.setError("Email is required.");
                return;
            } else {
                loginEmail.setError(null); // Clear the error if present
            }

            if (TextUtils.isEmpty(password)) {
                passwordLayout.setError("Password is required.");
                return;
            } else {
                passwordLayout.setError(null); // Clear the error if present
            }

            // Firebase login
            loginUser(email, password);
        });

        // Register button click listener
        Button registerBtn = findViewById(R.id.register);
        registerBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegisterPage.class);
            startActivity(intent);
        });

        // Forgot password button click listener
        Button forgotPasswordBtn = findViewById(R.id.forgotPass);
        forgotPasswordBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ForgotPasswordPage.class);
            startActivity(intent);
        });
    }

    private void loginUser(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Login successful, navigate to HomePage
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            String userId = email.substring(0, 9).toUpperCase();
                            Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity.this, HomePage.class);
                            intent.putExtra("USER_ID", userId); // Pass the user ID to HomePage
                            startActivity(intent);
                            finish(); // Close the login activity
                        }
                    } else {
                        // Login failed, show error message
                        Toast.makeText(MainActivity.this, "Login Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
