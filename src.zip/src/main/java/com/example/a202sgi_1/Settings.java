package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings); // XML file for enter OTP

        String userId = getIntent().getStringExtra("USER_ID");


        // Initialize BottomNavigationView
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Set a listener for menu item clicks
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.homepage) {
                    Intent intent = new Intent(Settings.this, HomePage.class);
                    intent.putExtra("USER_ID", userId); // Pass userId to HomePage
                    startActivity(intent);
                    return true;

                } else if (id == R.id.vehicle) {
                    Intent intent = new Intent(Settings.this, VehiclePage.class);
                    intent.putExtra("USER_ID", userId); // Pass userId to Vehicle Page
                    startActivity(intent);
                    return true;

                } else if (id == R.id.settings) {
                    // Handle settings click
                    return true;
                }
                return false;
            }

        });

        Button logoutBtn = findViewById(R.id.logout_button);
        logoutBtn.setOnClickListener(v -> {
            // Move back to LoginActivity when "Already have an account? Log in" is clicked
            Intent intent = new Intent(Settings.this, MainActivity.class);
            startActivity(intent);
        });

    }
}