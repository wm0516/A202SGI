package com.example.a202sgi_1;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

public class HomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page); // Ensure this is the correct layout file

        // Get the user ID from the intent
        String userId = getIntent().getStringExtra("USER_ID");
        if (userId == null) {
            Log.e("HomePage", "User ID is null");
            // Handle the error appropriately
        }
        System.out.println("USER_ID: " + userId);

        // Reference to the TextViews
        TextView studentID = findViewById(R.id.profileUserId);
        TextView userName = findViewById(R.id.profileUserName);
        TextView userEmail = findViewById(R.id.profileUserEmail);
        TextView userCourse = findViewById(R.id.profileUserCourse);
        TextView userContact = findViewById(R.id.profileUserContactNumber);

        // Fetch and display user data from Realtime
        getUserData(userId, studentID, userName, userEmail, userCourse, userContact);

        // Initialize BottomNavigationView and handle clicks
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.homepage) {
                    // Handle homepage click
                    return true;

                } else if (id == R.id.vehicle) {
                    // Handle vehicle click
                    Intent intent = new Intent(HomePage.this, VehiclePage.class);
                    intent.putExtra("USER_ID", userId); // Pass userId to Vehicle Page
                    startActivity(intent);
                    return true;

                } else if (id == R.id.settings) {
                    // Handle settings click
                    Intent intent = new Intent(HomePage.this, Settings.class);
                    intent.putExtra("USER_ID", userId); // Pass userId to Settings
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        // Handle button clicks
        Button calldoubleparkButton = findViewById(R.id.double_parking_button);
        calldoubleparkButton.setOnClickListener(v -> {
            // Handle double park button click
            Intent intent = new Intent(HomePage.this, SearchDoubleParking.class);
            startActivity(intent);
        });

        Button accessDiagramButton = findViewById(R.id.access_diagram);
        accessDiagramButton.setOnClickListener(v -> {
            // Handle access diagram button click
            // Intent intent = new Intent(HomePage.this, DiagramActivity.class);
            // startActivity(intent);
        });
    }

    // Method to get user data from Firebase Realtime Database and display in TextViews
    private void getUserData(String userId, TextView studentID, TextView userName, TextView userEmail, TextView userCourse, TextView userContact) {
        // Reference to user data in Realtime Database
        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // Use addListenerForSingleValueEvent to retrieve the data
        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Log the data retrieved for debugging
                    Log.d("HomePage", "Data retrieved: " + dataSnapshot.getValue());

                    studentID.setText(dataSnapshot.getKey());
                    userName.setText(dataSnapshot.child("name").getValue(String.class));
                    userEmail.setText(dataSnapshot.child("email").getValue(String.class));
                    userCourse.setText(dataSnapshot.child("user_course").getValue(String.class));
                    userContact.setText(dataSnapshot.child("phoneNo").getValue(String.class));
                } else {
                    studentID.setText("User not found");
                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle possible errors
                studentID.setText("Error fetching data: " + databaseError.getMessage());
            }
        });
    }


}


