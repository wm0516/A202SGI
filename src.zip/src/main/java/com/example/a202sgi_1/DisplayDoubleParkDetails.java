package com.example.a202sgi_1;

import static com.example.a202sgi_1.R.id.doubleParkPlateNo;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DisplayDoubleParkDetails extends AppCompatActivity {

    // private String ownerContact;  // Declare a variable to store the contact number

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_doublepark_details);  // XML file

        TextView carPlateNumber, carModel, carOwnerContact;
        Button callBtn;

        String vehicleId = getIntent().getStringExtra("vehicleId");

        carPlateNumber = findViewById(R.id.doubleParkPlateNo);
        carModel = findViewById(R.id.doubleParkModel);
        carOwnerContact = findViewById(R.id.doubleParkPhoneNo); // New text view for contact

        // Retrieve and display car details
        displayDetails(vehicleId, carPlateNumber, carModel, carOwnerContact);

        // Call button functionality
        callBtn = findViewById(R.id.callButton);
        callBtn.setOnClickListener(v -> {
            callBtn(vehicleId);
        });

        // Back button to go to home page
        Button backtohomepageBtn = findViewById(R.id.back_to_homepage);
        backtohomepageBtn.setOnClickListener(v -> {
            Intent intent = new Intent(DisplayDoubleParkDetails.this, HomePage.class);
            startActivity(intent);
            finish();// Navigate back to the home page
        });
    }

    private void callBtn(String vehicleId) {
        DatabaseReference contactNoRef = FirebaseDatabase.getInstance().getReference("Vehicles").child(vehicleId).child("phoneNo");

        // Attach a listener to retrieve the phone number
        contactNoRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Check if the phone number exists
                if (dataSnapshot.exists()) {
                    // Get the phone number as a string
                    String phoneNo = dataSnapshot.getValue(String.class);
                    // Do something with the phone number
                    System.out.println("Phone number: " + phoneNo);

                    // Create intent to open the dialer with the contact number
                    Intent callIntent = new Intent(Intent.ACTION_DIAL);
                    callIntent.setData(Uri.parse("tel:" + phoneNo));  // Pass the actual phone number, not the reference
                    startActivity(callIntent);  // Opens the dialer with the number ready to call
                } else {
                    System.out.println("Phone number not found for vehicleId: " + vehicleId);
                    Toast.makeText(DisplayDoubleParkDetails.this, "Contact number not available", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle possible errors
                System.out.println("Error retrieving phone number: " + databaseError.getMessage());
            }
        });
    }


    private void displayDetails(String vehicleId, TextView carPlateNumber, TextView carModel, TextView carOwnerContact) {
        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("Vehicles").child(vehicleId);

        // Use addListenerForSingleValueEvent to retrieve the data
        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Retrieve and display car details
                    carPlateNumber.setText("Vehicle Plate Number: " + dataSnapshot.child("plate").getValue(String.class));
                    carModel.setText("Vehicle Model: " + dataSnapshot.child("model").getValue(String.class));
                    //ownerContact = dataSnapshot.child("phoneNo").getValue(String.class);  // Save contact
                    carOwnerContact.setText("Owner's Contact Number: " + dataSnapshot.child("phoneNo").getValue(String.class));  // Display contact number
                } else {
                    Toast.makeText(DisplayDoubleParkDetails.this, "Vehicle not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(DisplayDoubleParkDetails.this, "Failed to retrieve data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
