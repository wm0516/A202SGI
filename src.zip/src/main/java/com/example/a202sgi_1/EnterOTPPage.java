package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class EnterOTPPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enter_otp); // XML file for enter OTP

        // Find the button and set the click listener
        Button continueBtn = findViewById(R.id.verify_Btn);
        continueBtn.setOnClickListener(v -> {
            // Move back to LoginActivity when "Already have an account? Log in" is clicked
            Intent intent = new Intent(EnterOTPPage.this, ResetNewPassword.class);
            startActivity(intent);
        });

        Button backLoginBtn = findViewById(R.id.backtoLogin_Btn);
        backLoginBtn.setOnClickListener(v -> {
            // Move back to LoginActivity when "Already have an account? Log in" is clicked
            Intent intent = new Intent(EnterOTPPage.this, MainActivity.class);
            startActivity(intent);
        });

    }
}