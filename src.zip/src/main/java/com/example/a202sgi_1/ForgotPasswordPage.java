package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ForgotPasswordPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgotpassword_page); // XML file for register

        // Find the button and set the click listener
        Button verifyBtn = findViewById(R.id.verify_Btn);
        verifyBtn.setOnClickListener(v -> {
            // Move back to LoginActivity when "Already have an account? Log in" is clicked
            Intent intent = new Intent(ForgotPasswordPage.this, EnterOTPPage.class);
            startActivity(intent);
        });

        Button backLoginBtn = findViewById(R.id.backtoLogin_Btn);
        backLoginBtn.setOnClickListener(v -> {
            // Move back to LoginActivity when "Already have an account? Log in" is clicked
            Intent intent = new Intent(ForgotPasswordPage.this, MainActivity.class);
            startActivity(intent);
        });
    }
}


