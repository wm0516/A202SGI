package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ResetNewPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resetnewpassword); // XML file for register

        // Find the button and set the click listener
        Button confirmBtn = findViewById(R.id.confirm_button);
        confirmBtn.setOnClickListener(v -> {
            // Move back to LoginActivity when "Already have an account? Log in" is clicked
            Intent intent = new Intent(ResetNewPassword.this, MainActivity.class);
            startActivity(intent);
        });

        Button backLoginBtn = findViewById(R.id.reg_ToLoginBtn);
        backLoginBtn.setOnClickListener(v -> {
            // Move back to LoginActivity when "Already have an account? Log in" is clicked
            Intent intent = new Intent(ResetNewPassword.this, MainActivity.class);
            startActivity(intent);
        });
    }
}


