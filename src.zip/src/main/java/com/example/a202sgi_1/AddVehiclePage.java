package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.TimeZone; // Import the TimeZone class

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AddVehiclePage extends AppCompatActivity {

    private TextInputLayout carModelLayout, carPlateLayout;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_vehicle_page);

        String userId = getIntent().getStringExtra("USER_ID");

        // Access the TextInputLayouts correctly
        carModelLayout = findViewById(R.id.car_model);
        carPlateLayout = findViewById(R.id.car_plate_number);

        Button confirmBtn = findViewById(R.id.confirm_button);
        confirmBtn.setOnClickListener(v -> {
            // Get the text values from TextInputLayout's EditTexts
            String carModel = carModelLayout.getEditText().getText().toString().trim().toUpperCase();
            String carPlate = carPlateLayout.getEditText().getText().toString().trim().toUpperCase();

            if (carModel.isEmpty() || carPlate.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save data directly to Firebase without using a Vehicle class
            addVehicleToFirebase(userId, carModel, carPlate);
        });

        Button backtoVehicleBtn = findViewById(R.id.back_to_vehicle_page);
        backtoVehicleBtn.setOnClickListener(v -> {
            Intent intent = new Intent(AddVehiclePage.this, VehiclePage.class);
            startActivity(intent);
            finish();
        });
    }

    private void addVehicleToFirebase(String userId, String model, String plate) {
        databaseReference = FirebaseDatabase.getInstance().getReference("Vehicles");
        DatabaseReference userPhoneNo = FirebaseDatabase.getInstance().getReference("Users").child(userId).child("phoneNo");

        // Create a unique vehicle ID
        String vehicleId = databaseReference.push().getKey();
        // To get the time when added new vehicle
        Date currentTime = Calendar.getInstance().getTime();

        // Define the desired format
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy h:mm a");

        // Set the timezone to your local timezone
        dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kuala_Lumpur")); // Replace with your correct timezone

        // Format the current date and time
        String formattedDate = dateFormat.format(currentTime);

        if (vehicleId != null) {
            userPhoneNo.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    String phoneNo = dataSnapshot.getValue(String.class);

                    if (phoneNo != null) {
                        Map<String, Object> vehicleData = new HashMap<>();
                        vehicleData.put("vehicleId", vehicleId);
                        vehicleData.put("userId", userId);
                        vehicleData.put("plate", plate);
                        vehicleData.put("model", model);
                        vehicleData.put("phoneNo", phoneNo);
                        vehicleData.put("added_time", formattedDate);

                        // Save vehicle data directly to Firebase using the Map
                        databaseReference.child(vehicleId).setValue(vehicleData)
                                .addOnCompleteListener(task -> {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(AddVehiclePage.this, "Vehicle added successfully", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(AddVehiclePage.this, VehiclePage.class));
                                        finish(); // Close the AddVehiclePage after adding
                                    } else {
                                        Toast.makeText(AddVehiclePage.this, "Failed to add vehicle", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    } else {
                        Toast.makeText(AddVehiclePage.this, "Phone number not found", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Toast.makeText(AddVehiclePage.this, "Error retrieving phone number", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}





