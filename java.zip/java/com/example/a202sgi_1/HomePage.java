package com.example.a202sgi_1;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Map;

public class HomePage extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private LinearLayout vehicleContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page); // Ensure this is the correct layout file


        // Initialize Firebase reference
        databaseReference = FirebaseDatabase.getInstance().getReference("Vehicles");

        // Initialize the container where vehicles will be displayed
        vehicleContainer = findViewById(R.id.vehicle_container_homePage); // Ensure this ID exists in XML

        // Get the user ID from the intent
        String userId = getIntent().getStringExtra("USER_ID");
        if (userId == null) {
            Log.e("HomePage", "User ID is null");
            // Handle the error appropriately
        }
        System.out.println("USER_ID: " + userId);

        // Reference to the TextViews
        TextView studentID = findViewById(R.id.profileUserId);
        TextView userName = findViewById(R.id.profileUserName);
        TextView userEmail = findViewById(R.id.profileUserEmail);
        TextView userCourse = findViewById(R.id.profileUserCourse);
        TextView userContact = findViewById(R.id.profileUserContactNumber);

        // Fetch and display user data from Realtime
        getUserData(userId, studentID, userName, userEmail, userCourse, userContact);

        // Initialize BottomNavigationView and handle clicks
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.homepage) {
                    // Handle homepage click
                    return true;

                } else if (id == R.id.vehicle) {
                    // Handle vehicle click
                    Intent intent = new Intent(HomePage.this, VehiclePage.class);
                    intent.putExtra("USER_ID", userId); // Pass userId to Vehicle Page
                    startActivity(intent);
                    return true;

                } else if (id == R.id.settings) {
                    // Handle settings click
                    Intent intent = new Intent(HomePage.this, Settings.class);
                    intent.putExtra("USER_ID", userId); // Pass userId to Settings
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        MaterialCardView searchDoublePark = findViewById(R.id.double_parking_button);
        searchDoublePark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle card click here, e.g., open the parking diagram
                Intent intent = new Intent(HomePage.this, SearchDoubleParking.class);
                intent.putExtra("USER_ID", userId); // Pass the user ID to HomePage
                startActivity(intent);
            }
        });

        MaterialCardView parkingView = findViewById(R.id.access_diagram);
        parkingView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle card click here, e.g., open the parking diagram
                // Intent intent = new Intent(HomePage.this, VehiclePage.class);
                // startActivity(intent);
            }
        });

        MaterialCardView vehicleView = findViewById(R.id.vehicle_button);
        vehicleView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle card click here, e.g., open the parking diagram
                Intent intent = new Intent(HomePage.this, VehiclePage.class);
                intent.putExtra("USER_ID", userId); // Pass the user ID to HomePage
                startActivity(intent);
            }
        });

        fetchAndDisplayVehicles(userId);

    }

    private void fetchAndDisplayVehicles(String userId) {
        // Query Firebase database for vehicles by userId
        databaseReference.orderByChild("userId").equalTo(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Clear the container before adding new cards
                    vehicleContainer.removeAllViews();

                    // Loop through each vehicle and add it to the layout
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Map<String, Object> vehicleData = (Map<String, Object>) snapshot.getValue();
                        if (vehicleData != null) {
                            String plate = (String) vehicleData.get("plate");
                            String model = (String) vehicleData.get("model");
                            createVehicleCard(plate, model); // Create a card for each vehicle
                        }
                    }
                } else {
                    Toast.makeText(HomePage.this, "No vehicles found for this user", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(HomePage.this, "Error loading data: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void createVehicleCard(String plate, String model) {
        // Create a new MaterialCardView
        MaterialCardView cardView = new MaterialCardView(this);

        // Set LayoutParams for cardView with margins (left, top, right, bottom)
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        // cardParams.setMargins(80, 50, 80, 0); // Set margins
        cardView.setLayoutParams(cardParams);
        // cardView.setCardElevation(10); // Card elevation for shadow effect
        cardView.setRadius(20); // Corner radius for smooth edges

        // Set the card background color
        cardView.setCardBackgroundColor(Color.TRANSPARENT);

        // Create a LinearLayout to contain the vehicle info
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL); // Horizontal layout to place model and plate in the same line
        layout.setPadding(50, 60, 50, 60); // Set padding inside the card

// TextView for the plate number (on the right)
        TextView plateTextView = new TextView(this);
        plateTextView.setTextColor(Color.parseColor("#000000"));
        plateTextView.setText(plate);
        plateTextView.setTextSize(20);
        plateTextView.setTypeface(null, Typeface.BOLD);
        plateTextView.setGravity(Gravity.END); // Align the text to the right side
        plateTextView.setBackground(null); // Remove any default background or drawable
        plateTextView.setLayoutParams(new LinearLayout.LayoutParams(
                0, // Width is 0, but weighted
                LinearLayout.LayoutParams.WRAP_CONTENT, // Height is wrap content
                1 // Weight is 1 to occupy the remaining space
        ));

// TextView for the model (on the left)
        TextView modelTextView = new TextView(this);
        modelTextView.setTextColor(Color.parseColor("#000000"));
        modelTextView.setText(model);
        modelTextView.setTextSize(20);
        modelTextView.setTypeface(null, Typeface.BOLD);
        modelTextView.setBackground(null); // Remove any default background or drawable
        modelTextView.setLayoutParams(new LinearLayout.LayoutParams(
                0, // Width of the text view is 0, but weighted
                LinearLayout.LayoutParams.WRAP_CONTENT, // Height is wrap content
                1 // Weight is 1 to push the plate TextView to the right
        ));


        // Add the views to the layout in the correct order
        layout.addView(modelTextView); // Add model TextView to the left (first)
        layout.addView(plateTextView); // Add plate TextView to the right (second)

        // Add the layout to the cardView
        cardView.addView(layout);

        // Add the cardView to the container (vehicleContainer is assumed to be a LinearLayout or similar)
        vehicleContainer.addView(cardView);
    }




    // Method to get user data from Firebase Realtime Database and display in TextViews
    private void getUserData(String userId, TextView studentID, TextView userName, TextView userEmail, TextView userCourse, TextView userContact) {
        // Reference to user data in Realtime Database
        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // Use addListenerForSingleValueEvent to retrieve the data
        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Log the data retrieved for debugging
                    Log.d("HomePage", "Data retrieved: " + dataSnapshot.getValue());

                    studentID.setText(dataSnapshot.getKey());
                    userName.setText(dataSnapshot.child("name").getValue(String.class));
                    userEmail.setText(dataSnapshot.child("email").getValue(String.class));
                    userCourse.setText(dataSnapshot.child("course").getValue(String.class));
                    userContact.setText(dataSnapshot.child("phoneNo").getValue(String.class));
                } else {
                    studentID.setText("User not found");
                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle possible errors
                studentID.setText("Error fetching data: " + databaseError.getMessage());
            }
        });
    }


}


