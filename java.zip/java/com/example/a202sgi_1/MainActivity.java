package com.example.a202sgi_1;

import android.os.Bundle;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth; // Firebase Auth instance
    private EditText loginEmail, loginPassword; // Input fields for login
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("Users"); // Users node in Realtime Database

        // Initialize UI elements correctly
        TextInputLayout emailLayout = findViewById(R.id.username); // Get the TextInputLayout for email
        TextInputLayout passwordLayout = findViewById(R.id.password); // Get the TextInputLayout for password

        // Get the EditText (or TextInputEditText) inside the TextInputLayout
        loginEmail = emailLayout.getEditText();
        loginPassword = passwordLayout.getEditText();

        // Login button click listener
        Button loginBtn = findViewById(R.id.login_btn);
        loginBtn.setOnClickListener(v -> {
            String email = loginEmail.getText().toString().trim().toLowerCase();
            String password = loginPassword.getText().toString().trim();

            Log.d("Tag", "User entered email: " + email);
            Log.d("Tag", "User entered password: " + password);

            // Input validation
            if (TextUtils.isEmpty(email)) {
                loginEmail.setError("Email is required.");
                return;
            } else {
                loginEmail.setError(null); // Clear the error if present
            }

            if (TextUtils.isEmpty(password)) {
                passwordLayout.setError("Password is required.");
                return;
            } else {
                passwordLayout.setError(null); // Clear the error if present
            }

            // Firebase login
            loginUser(email, password);
        });

        // Register button click listener
        Button registerBtn = findViewById(R.id.register);
        registerBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegisterPage.class);
            startActivity(intent);
        });

        // Forgot password button click listener
        Button forgotPasswordBtn = findViewById(R.id.forgotPass);
        forgotPasswordBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ForgotPasswordPage.class);
            startActivity(intent);
        });

        // Guest login button click listener
        Button guestBtn = findViewById(R.id.enter_as_guest);
        guestBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HomePageGuest.class);
            startActivity(intent);
        });

    }

    private void loginUser(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Login successful
                        FirebaseUser user = mAuth.getCurrentUser();

                        if (user != null) {
                            // Check if the email is verified
                            if (user.isEmailVerified()) {
                                // Email is verified, proceed to HomePage
                                String userId = email.substring(0, 9).toUpperCase();

                                // update the initialize to true as prove verify email
                                Map<String, Object> updates = new HashMap<>();
                                updates.put("isVerified", true);
                                mDatabase.child(userId).updateChildren(updates);

                                Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity.this, HomePage.class);
                                intent.putExtra("USER_ID", userId); // Pass the user ID to HomePage
                                startActivity(intent);
                                finish(); // Close the login activity
                            } else {
                                // Email is not verified, show error
                                Toast.makeText(MainActivity.this, "Please verify your email before logging in.", Toast.LENGTH_SHORT).show();
                                // Optionally, you could resend the verification email
                                user.sendEmailVerification().addOnCompleteListener(task1 -> {
                                    if (task1.isSuccessful()) {
                                        Toast.makeText(MainActivity.this, "Verification email sent to " + user.getEmail(), Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(MainActivity.this, "Failed to send verification email.", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }
                    } else {
                        // Login failed, show error message
                        Toast.makeText(MainActivity.this, "Login Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
