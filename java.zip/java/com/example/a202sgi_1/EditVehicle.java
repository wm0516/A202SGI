package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class EditVehicle extends AppCompatActivity {

    private TextInputLayout carModelLayout, carPlateLayout;
    private DatabaseReference databaseReference;
    private String selectedCarCategory; // Variable to store selected car category
    private TextView displayCarModelValue, displayCarPlateValue; // TextViews for display
    private String vehicleId; // Variable to store vehicle ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_vehicle);

        // Retrieve vehicle information from intent extras
        String userId = getIntent().getStringExtra("USER_ID");
        String model = getIntent().getStringExtra("model");
        String plate = getIntent().getStringExtra("plate");
        String category = getIntent().getStringExtra("category");
        vehicleId = getIntent().getStringExtra("vehicleId");

        // For testing
        System.out.println("User ID is (from edit): " + userId);
        System.out.println("Vehicle ID is (from edit): " + vehicleId);
        System.out.println("Model is (from edit): " + model);
        System.out.println("Plate is (from edit): " + plate);
        System.out.println("Category is (from edit): " + category);
        System.out.println();

        // Access the TextInputLayouts and TextViews
        carModelLayout = findViewById(R.id.edit_car_model);
        carPlateLayout = findViewById(R.id.edit_car_plate_number);
        displayCarModelValue = findViewById(R.id.display_car_model_value);
        displayCarPlateValue = findViewById(R.id.display_car_plate_value);

        // Display the vehicle model and plate if they are available
        if (model != null) {
            displayCarModelValue.setText("Model: " + model);
            carModelLayout.getEditText().setText(model); // Set initial value for editing
        }

        if (plate != null) {
            displayCarPlateValue.setText("Plate Number: " + plate);
            carPlateLayout.getEditText().setText(plate); // Set initial value for editing
        }

        Button confirmBtn = findViewById(R.id.update_button);
        confirmBtn.setOnClickListener(v -> {
            // Get the text values from TextInputLayout's EditTexts
            String carModel = carModelLayout.getEditText().getText().toString().trim().toUpperCase();
            String carPlate = carPlateLayout.getEditText().getText().toString().replaceAll("\\s+", "").toUpperCase();

            // Check if any fields are empty
            if (carModel.isEmpty() || carPlate.isEmpty() || selectedCarCategory == null) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save data directly to Firebase using existing vehicleId
            updateVehicleToFirebase(userId, carModel, carPlate, selectedCarCategory, vehicleId);
        });

        ImageView backtoVehicleBtn = findViewById(R.id.back_to_vehicle_page_from_edit);
        backtoVehicleBtn.setOnClickListener(v -> {
            Intent intent = new Intent(EditVehicle.this, VehiclePage.class);
            intent.putExtra("USER_ID", userId); // Pass the user ID to VehiclePage
            startActivity(intent);
            finish();
        });

        Spinner carCategorySpinner = findViewById(R.id.edit_car_category_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.car_categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        carCategorySpinner.setAdapter(adapter);

        // Set an OnItemSelectedListener to get the selected item
        carCategorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected item
                selectedCarCategory = parent.getItemAtPosition(position).toString();
                System.out.println("Vehicle chosen is: " + selectedCarCategory);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Handle case where no item is selected
                selectedCarCategory = null; // Set to null if no item is selected
                System.out.println("No vehicle chosen.");
            }
        });
    }

    private void updateVehicleToFirebase(String userId, String model, String plate, String category, String vehicleId) {
        databaseReference = FirebaseDatabase.getInstance().getReference("Vehicles");
        DatabaseReference userPhoneNo = FirebaseDatabase.getInstance().getReference("Users").child(userId).child("phoneNo");

        // Get the current time
        Date currentTime = Calendar.getInstance().getTime();

        // Define the desired date format
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy h:mm a");
        // Set the timezone to your local timezone
        dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kuala_Lumpur")); // Replace with your correct timezone
        // Format the current date and time
        String formattedDate = dateFormat.format(currentTime);

        // Use the existing vehicleId to update the existing record
        userPhoneNo.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String phoneNo = dataSnapshot.getValue(String.class);

                // If phone number is found, proceed to update the vehicle data
                if (phoneNo != null) {
                    Map<String, Object> vehicleData = new HashMap<>();
                    vehicleData.put("plate", plate);
                    vehicleData.put("model", model);
                    vehicleData.put("category", category); // Include category in the data
                    vehicleData.put("phoneNo", phoneNo);
                    vehicleData.put("edit_time", formattedDate);

                    // Update vehicle data directly in Firebase using the vehicleId
                    databaseReference.child(vehicleId).updateChildren(vehicleData)
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    Toast.makeText(EditVehicle.this, "Vehicle updated successfully", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(EditVehicle.this, VehiclePage.class);
                                    intent.putExtra("USER_ID", userId);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    Toast.makeText(EditVehicle.this, "Failed to update vehicle", Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    Toast.makeText(EditVehicle.this, "Phone number not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(EditVehicle.this, "Error retrieving phone number", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
