package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;


public class GuestParking extends AppCompatActivity {

    private EditText guestName, guestContact, guestVehicleModel, guestVehicleCarPlate, guestParkingTime;
    private Button submitBtn, backMainBtn;
    private String selectedTime; // Variable to store selected car category



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_parking); // XML file for register

        // Initialize UI elements
        guestName = findViewById(R.id.guest_name);
        guestContact = findViewById(R.id.guest_contact);
        guestVehicleModel = findViewById(R.id.guest_vehicle_model);
        guestVehicleCarPlate = findViewById(R.id.guest_vehicle_carplate);
        // guestParkingTime = findViewById(R.id.guest_parking_time);
        submitBtn = findViewById(R.id.submit_guest_parking);
        backMainBtn = findViewById(R.id.guest_back_home);

        // Register button click listener
        submitBtn.setOnClickListener(v -> {
            String name = guestName.getText().toString().trim();
            String phoneNo = guestContact.getText().toString().trim();
            String vehicleModel = guestVehicleModel.getText().toString().trim();
            String vehicleCarPlate = guestVehicleCarPlate.getText().toString().replaceAll("\\s+", "").toUpperCase();
            // String parkingTime = guestParkingTime.getText().toString().trim();


            // Validate input fields
            if (!validateName(name)) {
                guestName.setError("Invalid name format");
                return;
            }
            if (!validatePhoneNumber(phoneNo)) {
                guestContact.setError("Invalid contact number format");
                return;
            }
            if (vehicleModel.isEmpty()){
                guestVehicleModel.setError("Vehicle model can't be empty");
                return;
            }

            if (vehicleCarPlate.isEmpty()) {
                guestVehicleCarPlate.setError("Vehicle car plate number can't be empty");
                return;
            }

            guestUpdate(name, phoneNo, vehicleModel, vehicleCarPlate);


        });

        // Already have an account button click listener
        backMainBtn.setOnClickListener(v -> {
            Intent intent = new Intent(GuestParking.this, HomePageGuest.class);
            startActivity(intent);
        });

        Spinner parkingTimeSpinner = findViewById(R.id.parking_time_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.parking_time, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        parkingTimeSpinner.setAdapter(adapter);

        // Set an OnItemSelectedListener to get the selected item
        parkingTimeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected item
                selectedTime = parent.getItemAtPosition(position).toString();
                System.out.println("Time chosen is: " + selectedTime);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Handle case where no item is selected
                selectedTime = null; // Set to null if no item is selected
                System.out.println("No time chosen.");
            }
        });
    }

    private void guestUpdate(String name, String phoneNo, String vehicleModel, String vehicleCarPlate) {
        // Create a map to store simple user data
        Map<String, Object> guestData = new HashMap<>();
        guestData.put("name", name.toUpperCase());
        guestData.put("phoneNo", phoneNo);
        guestData.put("model", vehicleModel.toUpperCase());
        guestData.put("plate", vehicleCarPlate.toUpperCase());
        guestData.put("moveOutTime", selectedTime);

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Guests");

        databaseReference.child(vehicleCarPlate).setValue(guestData)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(GuestParking.this, "Guest data saved successfully!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(GuestParking.this, HomePageGuest.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(GuestParking.this, "Failed to save guest data.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private boolean validateName(String name) {
        return !name.isEmpty() && !name.matches(".*\\d.*");
    }

    // Validation for Phone Number (either 10 or 11 digits, and starts with '01')
    private boolean validatePhoneNumber(String phoneNo) {
        // Regex pattern to ensure phone number starts with '01' and is either 10 or 11 digits long
        String phonePattern = "^01\\d{8,9}$";

        // Match the phone number against the pattern
        return phoneNo.matches(phonePattern);
    }


}