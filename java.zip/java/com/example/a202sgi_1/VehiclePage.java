package com.example.a202sgi_1;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class VehiclePage extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private LinearLayout vehicleContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vehicle_page); // Ensure this is the correct layout file

        // Get the userId from the intent
        String userId = getIntent().getStringExtra("USER_ID");
        System.out.println("UserId: " + userId);

        // Initialize Firebase reference
        databaseReference = FirebaseDatabase.getInstance().getReference("Vehicles");

        // Initialize the container where vehicles will be displayed
        vehicleContainer = findViewById(R.id.vehicle_container); // Ensure this ID exists in XML

        // Bottom Navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.homepage) {
                    Intent intent = new Intent(VehiclePage.this, HomePage.class);
                    intent.putExtra("USER_ID", userId); // Pass userId to HomePage
                    startActivity(intent);
                    return true;
                } else if (id == R.id.vehicle) {
                    return true;
                } else if (id == R.id.settings) {
                    Intent intent = new Intent(VehiclePage.this, Settings.class);
                    intent.putExtra("USER_ID", userId); // Pass userId to Settings
                    startActivity(intent);
                }
                return false;
            }
        });

        // Add vehicle button logic
        ImageButton addBtn = findViewById(R.id.add_vehicle);
        addBtn.setOnClickListener(v -> {
            Intent intent = new Intent(VehiclePage.this, AddVehiclePage.class);
            intent.putExtra("USER_ID", userId); // Pass userId to AddVehiclePage
            startActivity(intent);
            finish();
        });

        // Fetch and display vehicles
        fetchAndDisplayVehicles(userId);
    }

    private void fetchAndDisplayVehicles(String userId) {
        // Query Firebase database for vehicles by userId
        databaseReference.orderByChild("userId").equalTo(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Clear the container before adding new cards
                    vehicleContainer.removeAllViews();

                    // Loop through each vehicle and add it to the layout
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Map<String, Object> vehicleData = (Map<String, Object>) snapshot.getValue();
                        if (vehicleData != null) {
                            String plate = (String) vehicleData.get("plate");
                            String model = (String) vehicleData.get("model");
                            String time = (String) vehicleData.get("added_time");
                            String category = (String) vehicleData.get("category");
                            String vehicleId = (String) vehicleData.get("vehicleId");
                            createVehicleCard(userId, plate, model, time, category, vehicleId); // Create a card for each vehicle
                        }
                    }
                } else {
                    Toast.makeText(VehiclePage.this, "No vehicles found for this user", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(VehiclePage.this, "Error loading data: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void createVehicleCard(String userId, String plate, String model, String time, String category, String vehicleId) {
        // Create a new MaterialCardView
        MaterialCardView cardView = new MaterialCardView(this);

        // Set LayoutParams for cardView with margins (left, top, right, bottom)
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(70, 30, 70, 30); // Set left and right margins to 50

        cardView.setLayoutParams(cardParams);
        cardView.setCardElevation(15);
        cardView.setRadius(50);
        cardView.setCardBackgroundColor(Color.parseColor("#FFFFFF")); // Set the background color using a hex code


        // Create a LinearLayout to contain the vehicle info
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 40);

        // Create the first line with plate number and delete icon
        LinearLayout firstLineLayout = new LinearLayout(this);
        firstLineLayout.setOrientation(LinearLayout.HORIZONTAL);

        // TextView for the plate number
        TextView plateTextView = new TextView(this);
        plateTextView.setText(plate);
        plateTextView.setTextSize(20);
        plateTextView.setTypeface(null, Typeface.BOLD);
        plateTextView.setLayoutParams(new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1 // Plate will take up most of the space
        ));

        // ImageView for the edit icon
        ImageButton editButton = new ImageButton(this);
        editButton.setImageResource(R.drawable.edit_icon);
        editButton.setLayoutParams(new LinearLayout.LayoutParams(
                130,
                130
        ));

        // Set an OnClickListener to navigate to another activity
        editButton.setOnClickListener(v -> {
            Intent intent = new Intent(VehiclePage.this, EditVehicle.class);
            intent.putExtra("USER_ID", userId);
            intent.putExtra("model", model);
            intent.putExtra("plate", plate);
            intent.putExtra("category", category);
            intent.putExtra("vehicleId", vehicleId);
            startActivity(intent);
        });


        // ImageView for the delete icon
        ImageButton deleteButton = new ImageButton(this);
        deleteButton.setImageResource(R.drawable.vehicle_delete_logo);
        deleteButton.setLayoutParams(new LinearLayout.LayoutParams(
                100,
                100
        ));
        deleteButton.setOnClickListener(v -> deleteVehicle(plate)); // Implement delete logic

        // Add plate TextView, "EDIT" TextView, and delete button to the first line layout
        firstLineLayout.addView(plateTextView);
        firstLineLayout.addView(editButton);
        firstLineLayout.addView(deleteButton);

        // Second TextView for the model
        TextView modelTextView = new TextView(this);
        modelTextView.setText("Vehicle model: " + model);
        modelTextView.setTextSize(14);
        modelTextView.setTextColor(Color.parseColor("#bdbdbd"));

        // Second TextView for the model
        TextView categoryTextView = new TextView(this);
        categoryTextView.setText("Vehicle category: " + category);
        categoryTextView.setTextSize(14);
        categoryTextView.setTextColor(Color.parseColor("#bdbdbd"));


        // TextView for the added time
        TextView added_timeTextView = new TextView(this);
        added_timeTextView.setText("Vehicle added on: " + time);
        added_timeTextView.setTextSize(14);
        added_timeTextView.setTextColor(Color.parseColor("#bdbdbd"));

        // Add the views to the card layout
        layout.addView(firstLineLayout);     // Adds first line with plate and delete button
        layout.addView(modelTextView);       // Adds the model TextView
        layout.addView(categoryTextView);
        layout.addView(added_timeTextView);  // Adds the added time TextView (This was missing)

        // Add the layout to the cardView
        cardView.addView(layout);

        // Add the cardView to the container
        vehicleContainer.addView(cardView);
    }


    private void deleteVehicle(String plate) {
        // Implement vehicle deletion logic (e.g., remove from Firebase)
        databaseReference.orderByChild("plate").equalTo(plate).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    snapshot.getRef().removeValue();
                    Toast.makeText(VehiclePage.this, "Vehicle deleted", Toast.LENGTH_SHORT).show();
                    // Refresh the page after deletion
                    recreate();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(VehiclePage.this, "Error deleting vehicle: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
