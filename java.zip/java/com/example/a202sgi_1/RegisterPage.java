package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;


public class RegisterPage extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private EditText regEmail, regUsername, regPhoneNo, regPassword, regPassword2;
    private CheckBox passwordToggle;
    private Button regBtn, regToLoginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_page); // XML file for register

        // Initialize Firebase Auth and Database
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("Users"); // Users node in Realtime Database

        // Initialize UI elements
        regEmail = findViewById(R.id.reg_email);
        regUsername = findViewById(R.id.reg_username);
        regPhoneNo = findViewById(R.id.reg_phoneNo);
        regPassword = findViewById(R.id.reg_password);
        regPassword2 = findViewById(R.id.reg_password2);
        passwordToggle = findViewById(R.id.password_toggle);
        regBtn = findViewById(R.id.reg_Btn);
        regToLoginBtn = findViewById(R.id.reg_ToLoginBtn);

        // Password visibility toggle logic
        passwordToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Show Password
                regPassword.setTransformationMethod(null);
                regPassword2.setTransformationMethod(null);
            } else {
                // Hide Password
                regPassword.setTransformationMethod(new PasswordTransformationMethod());
                regPassword2.setTransformationMethod(new PasswordTransformationMethod());
            }
            regPassword.setSelection(regPassword.getText().length());
            regPassword2.setSelection(regPassword2.getText().length());
        });

        // Register button click listener
        regBtn.setOnClickListener(v -> {
            String email = regEmail.getText().toString().trim();
            String name = regUsername.getText().toString().trim().toUpperCase();
            String phoneNo = regPhoneNo.getText().toString().trim();
            String password = regPassword.getText().toString().trim();
            String confirmPassword = regPassword2.getText().toString().trim();

            // Validate input fields
            if (!validateEmail(email)) {
                regEmail.setError("Invalid Email Format");
                return;
            }
            if (!validateName(name)){
                regUsername.setError("Invalid Name Format");
                return;
            }
            if (!validatePhoneNumber(phoneNo)) {
                regPhoneNo.setError("Invalid Phone Number");
                return;
            }
            if (!validatePassword(password)) {
                regPassword.setError("Must include 1 special character and at least 8 characters");
                return;
            }
            if (!password.equals(confirmPassword)) {
                regPassword2.setError("Passwords do not match");
                return;
            }

            // If all validations pass, register the user
            registerUser(email, name, phoneNo, password);
            // sendVerificationCode();
        });

        // Already have an account button click listener
        regToLoginBtn.setOnClickListener(v -> {
            Intent intent = new Intent(RegisterPage.this, MainActivity.class);
            startActivity(intent);
        });
    }

    // Validation for Email
    private boolean validateEmail(String email) {
        // Regular expression for validating the format 'P' followed by 8 digits and ends with '@student.newinti.edu.my'
        String emailPattern = "^p\\d{8}@student\\.newinti\\.edu\\.my$";

        // Match the email against the regex pattern (case-insensitive)
        return email.toLowerCase().matches(emailPattern);
    }


    private boolean validateName(String name) {
        return !name.isEmpty() && !name.matches(".*\\d.*");
    }

    // Validation for Phone Number (either 10 or 11 digits, and starts with '01')
    private boolean validatePhoneNumber(String phoneNo) {
        // Regex pattern to ensure phone number starts with '01' and is either 10 or 11 digits long
        String phonePattern = "^01\\d{8,9}$";

        // Match the phone number against the pattern
        return phoneNo.matches(phonePattern);
    }

    // Validation for Password (checks length, you can add more conditions like special chars, etc.)
    private boolean validatePassword(String password) {
        String regex = "^" +
                "(?=.*[a-z])" +  // at least one lowercase letter
                "(?=.*[A-Z])" +  // at least one uppercase letter
                "(?=.*[@#$%^&+=!])" + // at least 1 special character
                "(?=\\S+$)" +  // no white spaces
                ".{8,}" + // at least 8 characters
                "$";
        return Pattern.matches(regex, password);
    }

    private void registerUser(String email, String name, String phoneNo, String password) {
        // First, check if the email already exists in the database
        mDatabase.orderByChild("email").equalTo(email.toLowerCase()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot emailSnapshot) {
                if (emailSnapshot.exists()) {
                    // Email already registered
                    Toast.makeText(RegisterPage.this, "This email is already registered.", Toast.LENGTH_SHORT).show();
                } else {
                    // If the email is unique, check if the phone number already exists
                    mDatabase.orderByChild("phoneNo").equalTo(phoneNo).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot phoneSnapshot) {
                            if (phoneSnapshot.exists()) {
                                // Phone number already exists
                                Toast.makeText(RegisterPage.this, "This phone number is already registered.", Toast.LENGTH_SHORT).show();
                            } else {
                                // Both email and phone number are unique, proceed to create the user
                                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(RegisterPage.this, task -> {
                                    if (task.isSuccessful()) {
                                        // Registration is successful
                                        FirebaseUser user = mAuth.getCurrentUser(); // Get the currently authenticated user
                                        if (user != null) {
                                            String userId = email.substring(0, 9).toUpperCase();
                                            // Create a map to store simple user data
                                            Map<String, Object> userData = new HashMap<>();
                                            userData.put("email", email.toLowerCase());
                                            userData.put("name", name);
                                            userData.put("phoneNo", phoneNo);
                                            userData.put("isVerified", false); // User account is unverified by default

                                            // Insert user data into Firebase Realtime Database
                                            mDatabase.child(userId).setValue(userData)
                                                    .addOnCompleteListener(task1 -> {
                                                        if (task1.isSuccessful()) {
                                                            // Send verification email
                                                            user.sendEmailVerification().addOnCompleteListener(RegisterPage.this, task2 -> {
                                                                if (task2.isSuccessful()) {
                                                                    Toast.makeText(RegisterPage.this, "Verification Code Sent To " + user.getEmail(), Toast.LENGTH_SHORT).show();
                                                                    Toast.makeText(RegisterPage.this, "User Registered and Data Inserted", Toast.LENGTH_SHORT).show();
                                                                    Intent intent = new Intent(RegisterPage.this, MainActivity.class);
                                                                    startActivity(intent);
                                                                }
                                                            }).addOnFailureListener(e -> {
                                                                Toast.makeText(RegisterPage.this, "Verification Code Failed To Send To " + user.getEmail(), Toast.LENGTH_SHORT).show();
                                                            });
                                                        } else {
                                                            Toast.makeText(RegisterPage.this, "Failed to Insert Data", Toast.LENGTH_SHORT).show();
                                                        }
                                                    });
                                        }
                                    } else {
                                        // Registration failed
                                        Toast.makeText(RegisterPage.this, "Registration Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            // Handle possible errors
                            Toast.makeText(RegisterPage.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
                Toast.makeText(RegisterPage.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}