package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class AddVehiclePage extends AppCompatActivity {

    private TextInputLayout carModelLayout, carPlateLayout;
    private DatabaseReference databaseReference;
    private String selectedCarCategory; // Variable to store selected car category

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_vehicle_page);

        String userId = getIntent().getStringExtra("USER_ID");

        // Access the TextInputLayouts correctly
        carModelLayout = findViewById(R.id.car_model);
        carPlateLayout = findViewById(R.id.car_plate_number);

        Button confirmBtn = findViewById(R.id.confirm_button);
        confirmBtn.setOnClickListener(v -> {
            // Get the text values from TextInputLayout's EditTexts
            String carModel = carModelLayout.getEditText().getText().toString().trim().toUpperCase();
            String carPlate = carPlateLayout.getEditText().getText().toString().replaceAll("\\s+", "").toUpperCase();

            // Check if any fields are empty
            if (carModel.isEmpty() || carPlate.isEmpty() || selectedCarCategory == null) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save data directly to Firebase without using a Vehicle class
            addVehicleToFirebase(userId, carModel, carPlate, selectedCarCategory);
        });

        ImageView backtoVehicleBtn = findViewById(R.id.back_to_vehicle_page);
        backtoVehicleBtn.setOnClickListener(v -> {
            Intent intent = new Intent(AddVehiclePage.this, VehiclePage.class);
            intent.putExtra("USER_ID", userId); // Pass the user ID to HomePage
            startActivity(intent);
            finish();
        });

        Spinner carCategorySpinner = findViewById(R.id.car_category_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.car_categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        carCategorySpinner.setAdapter(adapter);

        // Set an OnItemSelectedListener to get the selected item
        carCategorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected item
                selectedCarCategory = parent.getItemAtPosition(position).toString();
                System.out.println("Vehicle chosen is: " + selectedCarCategory);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Handle case where no item is selected
                selectedCarCategory = null; // Set to null if no item is selected
                System.out.println("No vehicle chosen.");
            }
        });
    }

    private void addVehicleToFirebase(String userId, String model, String plate, String category) {
        databaseReference = FirebaseDatabase.getInstance().getReference("Vehicles");
        DatabaseReference userPhoneNo = FirebaseDatabase.getInstance().getReference("Users").child(userId).child("phoneNo");

        // Create a unique vehicle ID
        String vehicleId = databaseReference.push().getKey();
        // Get the current time
        Date currentTime = Calendar.getInstance().getTime();

        // Define the desired date format
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy h:mm a");
        // Set the timezone to your local timezone
        dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kuala_Lumpur")); // Replace with your correct timezone
        // Format the current date and time
        String formattedDate = dateFormat.format(currentTime);

        if (vehicleId != null) {
            userPhoneNo.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    String phoneNo = dataSnapshot.getValue(String.class);

                    if (phoneNo != null) {
                        Map<String, Object> vehicleData = new HashMap<>();
                        vehicleData.put("vehicleId", vehicleId);
                        vehicleData.put("userId", userId);
                        vehicleData.put("plate", plate);
                        vehicleData.put("model", model);
                        vehicleData.put("category", category); // Include category in the data
                        vehicleData.put("phoneNo", phoneNo);
                        vehicleData.put("added_time", formattedDate);

                        // Save vehicle data directly to Firebase using the Map
                        databaseReference.child(vehicleId).setValue(vehicleData)
                                .addOnCompleteListener(task -> {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(AddVehiclePage.this, "Vehicle added successfully", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(AddVehiclePage.this, VehiclePage.class);
                                        intent.putExtra("USER_ID", userId);
                                        startActivity(intent);
                                    } else {
                                        Toast.makeText(AddVehiclePage.this, "Failed to add vehicle", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    } else {
                        Toast.makeText(AddVehiclePage.this, "Phone number not found", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Toast.makeText(AddVehiclePage.this, "Error retrieving phone number", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
