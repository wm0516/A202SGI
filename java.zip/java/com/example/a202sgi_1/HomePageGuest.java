package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;

public class HomePageGuest extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page_guest); // Ensure this is the correct layout file

        MaterialCardView loginView = findViewById(R.id.unlock);
        loginView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle card click here, e.g., open the parking diagram
                Intent intent = new Intent(HomePageGuest.this, MainActivity.class);
                startActivity(intent);
            }
        });

        MaterialCardView parkingView = findViewById(R.id.access_diagram);
        parkingView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle card click here, e.g., open the parking diagram
                // Intent intent = new Intent(HomePageGuest.this, VehiclePage.class);
                // startActivity(intent);
            }
        });

        MaterialCardView help_support = findViewById(R.id.help_support);
        help_support.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle card click here, e.g., open the parking diagram
                Intent intent = new Intent(HomePageGuest.this, HelpAndSupportGuest.class);
                startActivity(intent);
            }
        });

        MaterialCardView temporaryParking = findViewById(R.id.temporary_parking);
        temporaryParking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle card click here, e.g., open the parking diagram
                Intent intent = new Intent(HomePageGuest.this, GuestParking.class);
                startActivity(intent);
            }
        });


    }

}


