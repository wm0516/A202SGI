package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;


public class Profile extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private EditText profileEmail, profileName, profilePhone, profileCourse, profileAddress, profilePassword, profilePassword2;
    private CheckBox passwordToggle;
    private Button updateBtn, backToProfileBtn;
    private ImageView backtosetting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_page); // XML file for register

        // Initialize Firebase Auth and Database
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("Users"); // Users node in Realtime Database
        String userId = getIntent().getStringExtra("USER_ID");

        // Initialize UI elements
        profileEmail = findViewById(R.id.edit_profile_email);
        profileName = findViewById(R.id.edit_profile_username);
        profilePhone = findViewById(R.id.edit_profile_phoneNo);
        profileCourse = findViewById(R.id.edit_profile_course);
        profileAddress = findViewById(R.id.edit_profile_house_address);
        profilePassword = findViewById(R.id.edit_profile_password1);
        profilePassword2 = findViewById(R.id.edit_profile_password2);
        passwordToggle = findViewById(R.id.password_toggle);

        updateBtn = findViewById(R.id.update_Btn);

        String phoneNo = profilePhone.getText().toString().trim();
        String course = profileCourse.getText().toString().trim();
        String house_address = profileAddress.getText().toString().trim();
        String password = profilePassword.getText().toString().trim();
        String confirmPassword = profilePassword2.getText().toString().trim();

        displayUser(userId, profileEmail, profileName);

        // Password visibility toggle logic
        passwordToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Show Password
                profilePassword.setTransformationMethod(null);
                profilePassword2.setTransformationMethod(null);
            } else {
                // Hide Password
                profilePassword.setTransformationMethod(new PasswordTransformationMethod());
                profilePassword2.setTransformationMethod(new PasswordTransformationMethod());
            }
            profilePassword.setSelection(profilePassword.getText().length());
            profilePassword2.setSelection(profilePassword2.getText().length());
        });

        // Register button click listener
        updateBtn.setOnClickListener(v -> {
            // Check each field, but allow updates for only the ones that are not empty
            if (!phoneNo.isEmpty() && !validatePhoneNumber(phoneNo)) {
                profilePhone.setError("Invalid Phone Number");
                return;
            }

            if (!course.isEmpty() && course.length() < 3) { // Example check for course length
                profileCourse.setError("Invalid Course entered");
                return;
            }

            if (!house_address.isEmpty() && house_address.length() < 5) { // Example check for address length
                profileAddress.setError("Invalid housing address");
                return;
            }

            if (!password.isEmpty()) {
                if (!validatePassword(password)) {
                    profilePassword.setError("Must include 1 special character and at least 8 characters");
                    return;
                }
                if (!password.equals(confirmPassword)) {
                    profilePassword2.setError("Passwords do not match");
                    return;
                }
            }

            // If all validations pass, update the user
            updateUser(userId, phoneNo, course ,house_address, password);
        });

        backtosetting = findViewById(R.id.back_to_settings);
        // Already have an account button click listener
        backtosetting.setOnClickListener(v -> {
            Intent intent = new Intent(Profile.this, Settings.class);
            intent.putExtra("USER_ID", userId); // Pass the user ID to HomePage
            startActivity(intent);
        });
    }

    private void displayUser(String userId, EditText profileEmail, EditText profileName) {
        // Reference to user data in Realtime Database
        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // Use addListenerForSingleValueEvent to retrieve the data
        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    profileName.setText(dataSnapshot.child("name").getValue(String.class));
                    profileEmail.setText(dataSnapshot.child("email").getValue(String.class));

                    // Set initial values for phoneNo, course, and house_address
                    profilePhone.setText(dataSnapshot.child("phoneNo").getValue(String.class));
                    profileCourse.setText(dataSnapshot.child("course").getValue(String.class));
                    profileAddress.setText(dataSnapshot.child("house_address").getValue(String.class));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle possible errors
                Log.e("Profile", "Database Error: " + databaseError.getMessage());
            }
        });
    }

    // Validation for Phone Number (either 10 or 11 digits, and starts with '01')
    private boolean validatePhoneNumber(String phoneNo) {
        // Regex pattern to ensure phone number starts with '01' and is either 10 or 11 digits long
        String phonePattern = "^01\\d{8,9}$";

        // Match the phone number against the pattern
        return phoneNo.matches(phonePattern);
    }

    // Validation for Password (checks length, you can add more conditions like special chars, etc.)
    private boolean validatePassword(String password) {
        String regex = "^" +
                "(?=.*[a-z])" +  // at least one lowercase letter
                "(?=.*[A-Z])" +  // at least one uppercase letter
                "(?=.*[@#$%^&+=!])" + // at least 1 special character
                "(?=\\S+$)" +  // no white spaces
                ".{8,}" + // at least 8 characters
                "$";
        return Pattern.matches(regex, password);
    }

    private void updateUser(String userId, String phoneNo, String course, String houseAddress, String password) {
        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // Create a map to hold the fields that need to be updated
        Map<String, Object> updates = new HashMap<>();
        updates.put("name", profileName.getText().toString().trim());
        updates.put("email", profileEmail.getText().toString().trim());

        // Store values in uppercase
        updates.put("phoneNo", profilePhone.getText().toString().trim());
        updates.put("course", profileCourse.getText().toString().trim().toUpperCase()); // Convert to uppercase
        updates.put("house_address", profileAddress.getText().toString().trim().toUpperCase()); // Convert to uppercase

        // Add non-empty fields to the update map
        if (!phoneNo.isEmpty()) {
            updates.put("phoneNo", phoneNo);
        } else {
            // No action needed
        }

        if (!course.isEmpty()) {
            updates.put("course", course.toUpperCase()); // Convert to uppercase
        }

        if (!houseAddress.isEmpty()) {
            updates.put("house_address", houseAddress.toUpperCase()); // Convert to uppercase
        }

        // Use updateChildren to update only specific fields without overwriting other data
        databaseRef.updateChildren(updates).addOnCompleteListener(task1 -> {
            if (task1.isSuccessful()) {
                Toast.makeText(getApplicationContext(), "Profile updated successfully", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Profile.this, Settings.class);
                intent.putExtra("USER_ID", userId); // Pass userId to Vehicle Page
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Update failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}