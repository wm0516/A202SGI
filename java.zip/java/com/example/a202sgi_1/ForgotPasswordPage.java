package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ForgotPasswordPage extends AppCompatActivity {

    String email_address;
    Button verifyBtn;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgotpassword_page); // Your XML layout file

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Initialize UI elements
        TextInputLayout emailaddress = findViewById(R.id.email_address);
        EditText emailaddress_text = emailaddress.getEditText(); // Use TextInputEditText for getting text

        // Initialize ProgressBar
        // progressBar = findViewById(R.id.progress_bar); // Make sure you have this in your layout

        // Find the button and set the click listener
        verifyBtn = findViewById(R.id.verify_Btn);
        verifyBtn.setOnClickListener(v -> {
            email_address = emailaddress_text.getText().toString().trim().toLowerCase();

            // Input validation
            if (TextUtils.isEmpty(email_address)) {
                emailaddress_text.setError("Email is required.");
                return;
            } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email_address).matches()) {
                emailaddress_text.setError("Please enter a valid email address.");
                return;
            } else {
                emailaddress_text.setError(null); // Clear the error if present
                Log.d("Tag", "User entered email: " + email_address);
            }

            ResetPassword(); // Call the reset password function
            //updatePassword(newPassword);

        });

        Button backLoginBtn = findViewById(R.id.backtoLogin_Btn);
        backLoginBtn.setOnClickListener(v -> {
            // Move back to MainActivity when back to login button is clicked
            Intent intent = new Intent(ForgotPasswordPage.this, MainActivity.class);
            startActivity(intent);
        });
    }

    // testing email: p21013604@student.newinti.edu.my
    private void ResetPassword() {

        // Reference to the Firebase Database
        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("Users");

        usersRef.orderByChild("email").equalTo(email_address).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        String userId = userSnapshot.getKey(); // Get user ID
                        Log.d("Tag", "User ID found: " + userId);

                        // Send password reset email
                        mAuth.sendPasswordResetEmail(email_address).addOnSuccessListener(unused -> {
                            Toast.makeText(ForgotPasswordPage.this, "Kindly check your email for the reset link", Toast.LENGTH_SHORT).show();
                            // Update the Firebase Realtime Database
                            Intent intent = new Intent(ForgotPasswordPage.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        }).addOnFailureListener(e -> {
                            Log.e("FirebaseAuthError", "Failed to send reset email: " + e.getMessage());
                            Toast.makeText(ForgotPasswordPage.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
                    }
                } else {
                    Toast.makeText(ForgotPasswordPage.this, "No user found with this email address.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("FirebaseDatabaseError", "Database error: " + databaseError.getMessage());
                Toast.makeText(ForgotPasswordPage.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    
}
