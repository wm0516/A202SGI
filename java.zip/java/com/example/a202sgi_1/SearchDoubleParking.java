package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SearchDoubleParking extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_double_park_car);  // XML file for enter OTP
        String userId = getIntent().getStringExtra("USER_ID");


        TextInputEditText plate_number = findViewById(R.id.car_plate_number);

        // Find the search button and set the click listener
        Button searchBtn = findViewById(R.id.search_button);
        searchBtn.setOnClickListener(v -> {
            // getDoubleParkingContactNo(userContact, plate_number);  // Call method to get contact number
            getDoubleParkingContactNo(plate_number, userId);  // Call method to get contact number
        });

        // Back button to go to home page
        ImageView backtohomepageBtn = findViewById(R.id.back_to_homepage_from_search);
        backtohomepageBtn.setOnClickListener(v -> {
            Intent intent = new Intent(SearchDoubleParking.this, HomePage.class);
            intent.putExtra("USER_ID", userId); // Pass the user ID to HomePage
            startActivity(intent);
            finish();
        });
    }

    // Method to retrieve the contact number based on the car plate number
    //private void getDoubleParkingContactNo(String userContact, TextView plate_number) {
    private void getDoubleParkingContactNo(TextInputEditText plate_number, String userId) {
        DatabaseReference vehiclesRef = FirebaseDatabase.getInstance().getReference("Vehicles");
        DatabaseReference guestRef = FirebaseDatabase.getInstance().getReference("Guests");


        String plateNumberInput = plate_number.getText().toString().replaceAll("\\s+", "").toUpperCase();
        if (plateNumberInput.isEmpty()) {
            Toast.makeText(SearchDoubleParking.this, "Please enter a car plate number.", Toast.LENGTH_SHORT).show();
            return;
        }

        vehiclesRef.orderByChild("plate").equalTo(plateNumberInput).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Iterate through the results (though there should ideally be only one)
                    for (DataSnapshot vehicleSnapshot : dataSnapshot.getChildren()) {

                        // String plateNumber = vehicleSnapshot.child("plate").getValue(String.class);
                        String contactNo = vehicleSnapshot.child("phoneNo").getValue(String.class);
                        String vehicleId = vehicleSnapshot.child("vehicleId").getValue(String.class);

                        // System.out.println("Vehicle ID is : " + vehicleId);
                        Log.d("TAG", "Vehicle ID is : " + vehicleId);
                        // Log.d("TAG", "Car owner contact number: " + contactNo);

                        if (contactNo != null) {
                            Intent intent = new Intent(SearchDoubleParking.this, DisplayDoubleParkDetails.class);
                            intent.putExtra("vehicleId", vehicleId); // Pass the user ID to HomePage
                            intent.putExtra("USER_ID", userId); // Pass the user ID to HomePage
                            startActivity(intent);
                            // Toast.makeText(SearchDoubleParking.this, "Contact number found: " + contactNo, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(SearchDoubleParking.this, "Contact number not available.", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    // No results found for the entered plate number
                    Toast.makeText(SearchDoubleParking.this, "He/Her wasn't a user", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(SearchDoubleParking.this, "Error fetching data: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        guestRef.orderByChild("plate").equalTo(plateNumberInput).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Iterate through the results (though there should ideally be only one)
                    for (DataSnapshot vehicleSnapshot : dataSnapshot.getChildren()) {

                        // String plateNumber = vehicleSnapshot.child("plate").getValue(String.class);
                        String contactNo = vehicleSnapshot.child("phoneNo").getValue(String.class);
                        String vehiclePlate = vehicleSnapshot.child("plate").getValue(String.class);

                        // System.out.println("Vehicle ID is : " + vehicleId);
                        Log.d("TAG", "Vehicle ID is : " + vehiclePlate);
                        // Log.d("TAG", "Car owner contact number: " + contactNo);

                        if (contactNo != null) {
                            Intent intent = new Intent(SearchDoubleParking.this, DisplayDoubleParkDetails.class);
                            intent.putExtra("vehicleId", vehiclePlate); // Pass the user ID to HomePage
                            intent.putExtra("USER_ID", userId); // Pass the user ID to HomePage
                            startActivity(intent);
                            // Toast.makeText(SearchDoubleParking.this, "Contact number found: " + contactNo, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(SearchDoubleParking.this, "Contact number not available.", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    // No results found for the entered plate number
                    Toast.makeText(SearchDoubleParking.this, "He/Her is a user", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(SearchDoubleParking.this, "Error fetching data: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}