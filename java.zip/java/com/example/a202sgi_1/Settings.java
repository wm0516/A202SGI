package com.example.a202sgi_1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings); // XML file for enter OTP

        String userId = getIntent().getStringExtra("USER_ID");

        TextView username = findViewById(R.id.profileUserName);
        TextView studentId = findViewById(R.id.profileUserId);

        getUserData(userId, studentId, username);

        // Initialize BottomNavigationView
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Set a listener for menu item clicks
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.homepage) {
                    Intent intent = new Intent(Settings.this, HomePage.class);
                    intent.putExtra("USER_ID", userId); // Pass userId to HomePage
                    startActivity(intent);
                    return true;

                } else if (id == R.id.vehicle) {
                    Intent intent = new Intent(Settings.this, VehiclePage.class);
                    intent.putExtra("USER_ID", userId); // Pass userId to Vehicle Page
                    startActivity(intent);
                    return true;

                } else if (id == R.id.settings) {
                    // Handle settings click
                    return true;
                }
                return false;
            }

        });

        ImageButton toProfile = findViewById(R.id.edit_to_profile);
        toProfile.setOnClickListener(v -> {
            // Move back to LoginActivity when "Already have an account? Log in" is clicked
            Intent intent = new Intent(Settings.this, Profile.class);
            intent.putExtra("USER_ID", userId); // Pass userId to Settings
            startActivity(intent);
            finish();
        });

        Button profileBtn = findViewById(R.id.enter_profile);
        profileBtn.setOnClickListener(v -> {
            // Move back to LoginActivity when "Already have an account? Log in" is clicked
            Intent intent = new Intent(Settings.this, Profile.class);
            intent.putExtra("USER_ID", userId); // Pass userId to Settings
            startActivity(intent);
            finish();
        });

        Button helpButton = findViewById(R.id.help_button);
        helpButton.setOnClickListener(v -> {
            // Check if userId is null
            if (userId != null) {
                Intent intent = new Intent(Settings.this, HelpAndSupport.class);
                intent.putExtra("USER_ID", userId); // Pass userId to HelpAndSupportGuest
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(Settings.this, "User ID is null", Toast.LENGTH_SHORT).show();
            }
        });


        Button logoutBtn = findViewById(R.id.logout_button);
        logoutBtn.setOnClickListener(v -> {
            // Move back to LoginActivity when "Already have an account? Log in" is clicked
            Intent intent = new Intent(Settings.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

    }

    private void getUserData(String userId, TextView studentId, TextView username) {
        // Reference to user data in Realtime Database
        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);

        // Use addListenerForSingleValueEvent to retrieve the data
        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Log the data retrieved for debugging
                    Log.d("HomePage", "Data retrieved: " + dataSnapshot.getValue());

                    studentId.setText(dataSnapshot.getKey());
                    username.setText(dataSnapshot.child("name").getValue(String.class));
                    // userEmail.setText(dataSnapshot.child("email").getValue(String.class));
                    // userCourse.setText(dataSnapshot.child("user_course").getValue(String.class));
                    // userContact.setText(dataSnapshot.child("phoneNo").getValue(String.class));
                } else {
                    studentId.setText("User not found");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle possible errors
                studentId.setText("Error fetching data: " + databaseError.getMessage());
            }
        });

    }
}