package com.example.a202sgi_1;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DisplayDoubleParkDetails extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_doublepark_details);  // XML file

        TextView carPlateNumber, carModel, carOwnerName, carOwnerContact, carLeavingTime;
        Button callBtn;

        String userId = getIntent().getStringExtra("USER_ID");
        String vehicleId = getIntent().getStringExtra("vehicleId");
        String plate = getIntent().getStringExtra("vehicleId");

        carPlateNumber = findViewById(R.id.doubleParkPlateNo);
        carModel = findViewById(R.id.doubleParkModel);
        carOwnerName = findViewById(R.id.doubleParkOwnerName);
        carOwnerContact = findViewById(R.id.doubleParkPhoneNo); // New text view for contact
        carLeavingTime = findViewById(R.id.doubleParkLeavingTime);

        // Retrieve and display car details (for user)
        displayDetails(vehicleId, plate, carPlateNumber, carModel, carOwnerName, carOwnerContact, carLeavingTime);

        // Call button functionality
        callBtn = findViewById(R.id.callButton);
        callBtn.setOnClickListener(v -> {
            callBtn(vehicleId, plate);
        });

        // Back button to search double park
        ImageView backtodobleparkBtn = findViewById(R.id.back_to_double_parking_search);
        backtodobleparkBtn.setOnClickListener(v -> {
            Intent intent = new Intent(DisplayDoubleParkDetails.this, SearchDoubleParking.class);
            intent.putExtra("USER_ID", userId); // Pass the user ID to HomePage
            startActivity(intent);
            finish();
        });

        // Call guard for help
        TextView callGuardTextView = findViewById(R.id.noCallAnswer);
        callGuardTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create the intent to dial the guard's number
                String phoneNumber = "0101234567"; // Replace with the guard's number
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:" + phoneNumber)); // Set the data for the intent
                startActivity(callIntent); // Start the activity to dial the number
            }
        });


    }

    private void callBtn(String vehicleId, String plate) {
        DatabaseReference contactNoRef = FirebaseDatabase.getInstance().getReference("Vehicles").child(vehicleId).child("phoneNo");
        DatabaseReference contactNoGuestRef = FirebaseDatabase.getInstance().getReference("Guests").child(plate).child("phoneNo");

        // Attach a listener to retrieve the phone number
        contactNoRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Check if the phone number exists
                if (dataSnapshot.exists()) {
                    // Get the phone number as a string
                    String phoneNo = dataSnapshot.getValue(String.class);
                    // Do something with the phone number
                    System.out.println("Phone number: " + phoneNo);

                    // Create intent to open the dialer with the contact number
                    Intent callIntent = new Intent(Intent.ACTION_DIAL);
                    callIntent.setData(Uri.parse("tel:" + phoneNo));  // Pass the actual phone number, not the reference
                    startActivity(callIntent);  // Opens the dialer with the number ready to call
                } else {
                    System.out.println("Phone number not found for vehicleId: " + vehicleId);
                    Toast.makeText(DisplayDoubleParkDetails.this, "Contact number not available", Toast.LENGTH_SHORT).show();
                }
            }



            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle possible errors
                System.out.println("Error retrieving phone number: " + databaseError.getMessage());
            }
        });

        contactNoGuestRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Check if the phone number exists
                if (dataSnapshot.exists()) {
                    // Get the phone number as a string
                    String phoneNo = dataSnapshot.getValue(String.class);
                    // Do something with the phone number
                    System.out.println("Phone number: " + phoneNo);

                    // Create intent to open the dialer with the contact number
                    Intent callIntent = new Intent(Intent.ACTION_DIAL);
                    callIntent.setData(Uri.parse("tel:" + phoneNo));  // Pass the actual phone number, not the reference
                    startActivity(callIntent);  // Opens the dialer with the number ready to call
                } else {
                    System.out.println("Phone number not found for vehicleId: " + vehicleId);
                    Toast.makeText(DisplayDoubleParkDetails.this, "Contact number not available", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle possible errors
                System.out.println("Error retrieving phone number: " + databaseError.getMessage());
            }
        });
    }


    private void displayDetails(String vehicleId, String plate, TextView carPlateNumber, TextView carModel, TextView carOwnerName, TextView carOwnerContact, TextView carLeavingTime) {
        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("Vehicles").child(vehicleId);
        DatabaseReference guestRef = FirebaseDatabase.getInstance().getReference("Guests").child(plate);

        final boolean[] dataFound = {false}; // To track if any data is found

        // Use addListenerForSingleValueEvent to retrieve the data
        databaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String nameId = dataSnapshot.child("userId").getValue(String.class);
                    System.out.println("Display name: " + nameId);

                    // Retrieve and display car details
                    carPlateNumber.setText(dataSnapshot.child("plate").getValue(String.class));
                    carModel.setText("Vehicle Model: " + dataSnapshot.child("model").getValue(String.class));
                    carOwnerContact.setText("Owner's Contact Number: " + dataSnapshot.child("phoneNo").getValue(String.class));
                    carLeavingTime.setText("");

                    // Retrieve the owner's name asynchronously
                    DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users").child(nameId).child("name");
                    userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot userSnapshot) {
                            if (userSnapshot.exists()) {
                                String fullName = userSnapshot.getValue(String.class);
                                String firstName = fullName != null && !fullName.isEmpty() ? fullName.split(" ")[0] : "Unknown";
                                carOwnerName.setText("Owner's name: Mr./Miss " + firstName);
                            } else {
                                carOwnerName.setText("Owner name not found");
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            Toast.makeText(DisplayDoubleParkDetails.this, "Failed to retrieve owner's name", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(DisplayDoubleParkDetails.this, "Failed to retrieve data", Toast.LENGTH_SHORT).show();
            }
        });

        guestRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    carPlateNumber.setText("Vehicle Plate Number: " + dataSnapshot.child("plate").getValue(String.class));
                    carOwnerName.setText("Owner address: " + dataSnapshot.child("name").getValue(String.class));
                    carModel.setText("Vehicle Model: " + dataSnapshot.child("model").getValue(String.class));
                    carOwnerContact.setText("Owner's Contact Number: " + dataSnapshot.child("phoneNo").getValue(String.class));
                    carLeavingTime.setText("Vehicle Move Out Time (in estimate): " + dataSnapshot.child("moveOutTime").getValue(String.class) + " (time chosen by guest)");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(DisplayDoubleParkDetails.this, "Failed to retrieve data", Toast.LENGTH_SHORT).show();
            }
        });

    }

}
