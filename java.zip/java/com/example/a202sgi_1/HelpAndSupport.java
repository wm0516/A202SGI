package com.example.a202sgi_1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class HelpAndSupport extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help_and_support);  // XML file
        String userId = getIntent().getStringExtra("USER_ID");

        // Back button to go to home page
        ImageView backtohomepageBtn = findViewById(R.id.back_to_settings_from_helpandsupport_guest);
        backtohomepageBtn.setOnClickListener(v -> {
            Intent intent = new Intent(HelpAndSupport.this, Settings.class);
            intent.putExtra("USER_ID", userId); // Pass userId to Settings
            startActivity(intent);
        });

        // Call guard for help
        LinearLayout callGuard = findViewById(R.id.call_guard);
        callGuard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create the intent to dial the guard's number
                String phoneNumber = "0101234567"; // Replace with the guard's number
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:" + phoneNumber)); // Set the data for the intent
                startActivity(callIntent); // Start the activity to dial the number
            }
        });

        // Call management for help
        LinearLayout callManagement = findViewById(R.id.call_management);
        callManagement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create the intent to dial the guard's number
                String phoneNumber = "0101234567"; // Replace with the guard's number
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:" + phoneNumber)); // Set the data for the intent
                startActivity(callIntent); // Start the activity to dial the number
            }
        });
    }
}
